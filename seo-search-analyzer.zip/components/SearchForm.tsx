import React, { useState } from 'react';
import { COUNTRIES } from '../constants';
import type { Country } from '../types';
import { SearchIcon, GlobeIcon } from './icons';

interface SearchFormProps {
  onSearch: (keywords: string, country: string) => void;
  isLoading: boolean;
}

export const SearchForm: React.FC<SearchFormProps> = ({ onSearch, isLoading }) => {
  const [keywords, setKeywords] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<Country>(COUNTRIES[0]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (keywords.trim()) {
      onSearch(keywords.trim(), selectedCountry.name);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-base-200 p-6 rounded-xl shadow-lg border border-base-300">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="keywords" className="block text-sm font-medium text-slate-400 mb-2">Keywords</label>
          <div className="relative">
            <input
              type="text"
              id="keywords"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
              placeholder="e.g., 'latest AI developments'"
              className="w-full bg-base-300 border border-slate-600 rounded-lg py-3 px-4 text-white placeholder-slate-500 focus:ring-2 focus:ring-brand-secondary focus:border-brand-secondary transition duration-200"
              required
            />
             <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <SearchIcon className="h-5 w-5 text-slate-500" />
            </div>
          </div>
        </div>
        <div>
          <label htmlFor="country" className="block text-sm font-medium text-slate-400 mb-2">Country</label>
          <div className="relative">
            <select
              id="country"
              value={selectedCountry.code}
              onChange={(e) => {
                const country = COUNTRIES.find(c => c.code === e.target.value);
                if (country) setSelectedCountry(country);
              }}
              className="w-full bg-base-300 border border-slate-600 rounded-lg py-3 px-4 text-white focus:ring-2 focus:ring-brand-secondary focus:border-brand-secondary transition duration-200 appearance-none"
            >
              {COUNTRIES.map((country) => (
                <option key={country.code} value={country.code}>
                  {country.name}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <GlobeIcon className="h-5 w-5 text-slate-500" />
            </div>
          </div>
        </div>
      </div>
      <div className="mt-6">
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center items-center bg-brand-primary hover:bg-blue-600 text-white font-bold py-3 px-4 rounded-lg transition duration-300 ease-in-out disabled:bg-slate-600 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Analyzing SERP...' : 'Analyze Top 10 Results'}
        </button>
      </div>
    </form>
  );
};