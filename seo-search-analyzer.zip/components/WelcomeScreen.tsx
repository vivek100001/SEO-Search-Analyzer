import React from 'react';
import { SparklesIcon } from './icons';

export const WelcomeScreen: React.FC = () => {
    return (
        <div className="text-center bg-base-200 p-8 md:p-12 rounded-lg border border-dashed border-base-300/50">
            <div className="flex justify-center items-center mb-4">
                <SparklesIcon className="w-12 h-12 text-yellow-400" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Unlock SEO Insights from Top Search Results</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
                Enter keywords and a country to get an AI-powered analysis of the top 10 Google search results. This tool synthesizes data to provide an overall summary, actionable content suggestions, and key SEO takeaways to dominate the SERPs.
            </p>
        </div>
    );
};