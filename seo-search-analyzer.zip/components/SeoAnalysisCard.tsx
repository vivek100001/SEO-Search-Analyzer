import React from 'react';
import type { AggregatedSeoAnalysis } from '../types';
import { LightBulbIcon, TagIcon, DocumentTextIcon, LinkIcon } from './icons';

interface AnalysisResultProps {
  analysis: AggregatedSeoAnalysis;
}

const AnalysisSection: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => (
    <div className="bg-gradient-to-br from-base-200 to-base-200/50 p-6 rounded-xl shadow-lg border border-base-300">
        <div className="flex items-center space-x-3 mb-4">
            {icon}
            <h3 className="text-xl font-bold text-slate-100">{title}</h3>
        </div>
        <div className="text-slate-300 space-y-3 text-base leading-relaxed">
            {children}
        </div>
    </div>
);

const ListItem: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <li className="flex items-start">
        <svg className="w-4 h-4 mr-3 mt-1.5 text-brand-secondary flex-shrink-0" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="m5.25 4.5 7.5 7.5-7.5 7.5" /></svg>
        <span>{children}</span>
    </li>
);

export const AnalysisResult: React.FC<AnalysisResultProps> = ({ analysis }) => {
  return (
    <div className="space-y-8">
        <h2 className="text-3xl font-bold text-white text-center">SERP Analysis Report</h2>

        <AnalysisSection title="Overall Summary" icon={<DocumentTextIcon className="w-7 h-7 text-brand-secondary" />}>
            <p>{analysis.overallSummary}</p>
        </AnalysisSection>

        <AnalysisSection title="Content Suggestions" icon={<LightBulbIcon className="w-7 h-7 text-brand-secondary" />}>
            <ul className="space-y-3">
                {analysis.contentSuggestions.map((suggestion, index) => (
                    <ListItem key={index}>{suggestion}</ListItem>
                ))}
            </ul>
        </AnalysisSection>

        <AnalysisSection title="Key SEO Takeaways" icon={<TagIcon className="w-7 h-7 text-brand-secondary" />}>
            <ul className="space-y-3">
                {analysis.seoTakeaways.map((takeaway, index) => (
                    <ListItem key={index}>{takeaway}</ListItem>
                ))}
            </ul>
        </AnalysisSection>

        <AnalysisSection title="Top Ranking Pages Analyzed" icon={<LinkIcon className="w-7 h-7 text-brand-secondary" />}>
            <div className="space-y-3">
                {analysis.topRankingPages.map((page, index) => (
                    <a 
                        key={index} 
                        href={page.url} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="group block bg-base-300/50 p-3 rounded-md hover:bg-base-300 transition-colors duration-200 border border-base-300"
                    >
                        <p className="font-semibold text-slate-200 group-hover:text-brand-secondary truncate">{page.title}</p>
                        <p className="text-xs text-slate-400 truncate mt-1">{page.url}</p>
                    </a>
                ))}
            </div>
        </AnalysisSection>
    </div>
  );
};