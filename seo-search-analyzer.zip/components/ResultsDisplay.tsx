import React from 'react';
import type { AggregatedSeoAnalysis } from '../types';
import { AnalysisResult } from './SeoAnalysisCard';

interface ResultsDisplayProps {
  results: AggregatedSeoAnalysis;
}

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results }) => {
  return (
    <div className="space-y-8 animate-fade-in">
        <AnalysisResult analysis={results} />
    </div>
  );
};