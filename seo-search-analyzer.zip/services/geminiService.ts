import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { AggregatedSeoAnalysis } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

function parseJsonFromText(text: string): any | null {
    const match = text.match(/```json\s*([\s\S]*?)\s*```/);
    if (!match || !match[1]) {
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error("Failed to parse response text as JSON:", text);
            return null;
        }
    }
    try {
        return JSON.parse(match[1]);
    } catch (error) {
        console.error("Error parsing JSON from response:", error);
        console.error("Raw content:", match[1]);
        return null;
    }
}


export const fetchSeoAnalysis = async (keywords: string, country: string): Promise<AggregatedSeoAnalysis> => {
    const prompt = `
    You are an expert SEO strategist and content analyst.
    Your primary task is to analyze the top 10 Google search results for a given keyword and country to identify patterns, user intent, and content opportunities.

    Based on the Google Search results for "${keywords}" in ${country}, please perform a comprehensive analysis of the Search Engine Results Page (SERP).

    Return your findings as a single, valid JSON object inside a JSON code block.
    The object MUST conform to the following structure:
    {
      "overallSummary": "A detailed summary of the common themes, content formats (e.g., listicles, guides, videos), and the primary user intent (e.g., informational, commercial, navigational) you observed across the top 10 search results.",
      "contentSuggestions": [
        "A list of 3-5 actionable and specific content ideas or unique angles that could rank well, based on identified content gaps or opportunities. Be creative and strategic.",
        "Example: 'Create a comprehensive 'how-to' guide with original images, as most results are text-only overviews.'"
      ],
      "seoTakeaways": [
        "A list of 3-5 critical SEO insights. Focus on actionable takeaways for ranking for this keyword.",
        "Example: 'The average word count of top-ranking pages is over 2,500 words, indicating a need for in-depth content.', 'Pages featuring an FAQ section are prominent, likely targeting People Also Ask boxes.'"
      ],
      "topRankingPages": [
        {
          "title": "The full title of a top-ranking page.",
          "url": "The full URL of that top-ranking page."
        }
      ]
    }

    You MUST extract the title and URL for at least 5 of the top-ranking pages you analyzed and include them in the 'topRankingPages' array.
    Do not add any text before or after the JSON code block. Your response must only be the JSON.
    `;
    
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });

        const analysisResult = parseJsonFromText(response.text);

        if (!analysisResult || typeof analysisResult !== 'object' || Array.isArray(analysisResult)) {
             throw new Error("AI failed to return a valid analysis in the expected JSON object format. Please try refining your keywords.");
        }
        
        if (
            !analysisResult.overallSummary || 
            !Array.isArray(analysisResult.contentSuggestions) || 
            !Array.isArray(analysisResult.seoTakeaways) ||
            !Array.isArray(analysisResult.topRankingPages)
        ) {
            throw new Error("The received analysis is incomplete or in the wrong format.");
        }

        return analysisResult as AggregatedSeoAnalysis;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        if (error instanceof Error) {
            throw error;
        }
        throw new Error("Failed to fetch data from the AI service. The service might be temporarily unavailable or the request was blocked.");
    }
};